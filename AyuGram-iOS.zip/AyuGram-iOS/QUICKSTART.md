# 🚀 Быстрый старт AyuGram iOS

## За 5 минут

### 1. Получите API ключи (2 минуты)
1. Откройте https://my.telegram.org/apps
2. Войдите с номером телефона
3. Создайте приложение
4. Скопируйте `api_id` и `api_hash`

### 2. Настройте проект (1 минута)
1. Откройте `AyuGram.xcodeproj` в Xcode
2. Файл [AyuGram/Models/TelegramManager.swift](AyuGram/Models/TelegramManager.swift#L29-L30)
3. Вставьте ваши ключи:
```swift
let apiId = 12345 // ← Ваш API ID
let apiHash = "abc..." // ← Ваш API Hash
```

### 3. Установите TDLib (2 минуты)

**Простой способ** - через Swift Package Manager:
1. Xcode → File → Add Packages
2. URL: `https://github.com/Swiftgram/TDLibKit.git`
3. Add Package

**ИЛИ** закомментируйте интеграцию для теста интерфейса

### 4. Запустите! (30 секунд)
1. Выберите симулятор iPhone в Xcode
2. Нажмите ▶️ (или Cmd+R)
3. Готово!

---

## Полная инструкция
См. [INSTALLATION.md](INSTALLATION.md)

---

## Основные файлы проекта

```
AyuGram-iOS/
├── 📱 AyuGram/               # Основное приложение
│   ├── AyuGramApp.swift      # ← Точка входа
│   ├── ContentView.swift     # ← Главный экран
│   │
│   ├── 📊 Models/            # Модели данных
│   │   ├── TelegramManager.swift    # Менеджер Telegram
│   │   ├── AyuGramSettings.swift    # Настройки AyuGram
│   │   └── Models.swift             # Структуры данных
│   │
│   ├── 🎨 Views/             # Интерфейс
│   │   ├── AuthenticationView.swift # Вход
│   │   ├── ChatsListView.swift      # Список чатов
│   │   ├── ChatView.swift           # Чат
│   │   └── SettingsView.swift       # Настройки
│   │
│   └── ⚙️ Services/          # Сервисы
│       ├── TDLibManager.swift       # TDLib интеграция
│       └── MessageStorage.swift     # Хранилище
│
├── 📄 README.md              # Описание проекта
├── 📋 INSTALLATION.md        # Установка
├── 🔧 Podfile               # Зависимости
└── 📦 Assets/               # Ресурсы
```

---

## Функции AyuGram

### ✅ Реализовано
- 👻 **Режим призрака** - скрытие онлайн-статуса
- 🕵️ **Режим шпиона** - чтение без "прочитано"
- 💾 **Сохранение истории** - локальное хранилище
- 📸 **Скриншоты в секретных чатах**
- 🗑️ **Просмотр удаленных сообщений**
- 🎨 **Настройка темы и шрифта**
- 🔍 **Фильтры сообщений**
- 🆔 **Отображение ID**
- 🔒 **Анонимная пересылка**
- ☁️ **AyuSync синхронизация**

### ⏳ В разработке
- Медиа-сообщения (фото, видео)
- Голосовые сообщения
- Стикеры и GIF
- Уведомления
- Расширенный поиск

---

## Где что находится

### Добавить новую функцию
1. Настройки → [AyuGramSettings.swift](AyuGram/Models/AyuGramSettings.swift)
2. UI → [SettingsView.swift](AyuGram/Views/SettingsView.swift)
3. Логика → [TDLibManager.swift](AyuGram/Services/TDLibManager.swift)

### Изменить дизайн
- Чаты → [ChatsListView.swift](AyuGram/Views/ChatsListView.swift)
- Сообщения → [ChatView.swift](AyuGram/Views/ChatView.swift)
- Настройки → [SettingsView.swift](AyuGram/Views/SettingsView.swift)

### Работа с сообщениями
- Отправка/получение → [TelegramManager.swift](AyuGram/Models/TelegramManager.swift)
- Хранение → [MessageStorage.swift](AyuGram/Services/MessageStorage.swift)
- Модели → [Models.swift](AyuGram/Models/Models.swift)

---

## Частые вопросы

**Q: Приложение не подключается к Telegram**  
A: Проверьте API ключи в TelegramManager.swift

**Q: TDLib not found**  
A: Установите через Swift Package Manager или CocoaPods

**Q: Не могу установить на iPhone**  
A: Настройки → General → Device Management → Доверить

**Q: Режим призрака не работает**  
A: Это ограничение Telegram API, работает частично

**Q: Безопасно ли это?**  
A: Используйте на тестовом аккаунте, возможна блокировка

---

## Контакты и помощь

- 📖 Полная документация: [README.md](README.md)
- 🔧 Инструкция по установке: [INSTALLATION.md](INSTALLATION.md)
- 🐛 Сообщить об ошибке: GitHub Issues
- 💬 Telegram: @ayugram_support

---

**⚠️ ВНИМАНИЕ**: Это неофициальный клиент Telegram. Используйте на свой страх и риск!

Сделано с ❤️ для iOS
