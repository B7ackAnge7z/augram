# Contributing to AyuGram iOS

Спасибо за интерес к проекту! 🎉

## Как внести вклад

### Сообщить об ошибке
1. Проверьте, что проблема еще не была описана в [Issues](https://github.com/yourusername/ayugram-ios/issues)
2. Создайте новый Issue с описанием:
   - Шаги для воспроизведения
   - Ожидаемое поведение
   - Фактическое поведение
   - Скриншоты (если возможно)
   - Версия iOS
   - Версия приложения

### Предложить функцию
1. Создайте Issue с меткой "feature request"
2. Опишите:
   - Зачем нужна функция
   - Как она должна работать
   - Примеры использования

### Отправить код

#### Подготовка
```bash
# Fork репозитория на GitHub

# Клонировать ваш форк
git clone https://github.com/YOUR_USERNAME/ayugram-ios.git
cd ayugram-ios

# Добавить upstream
git remote add upstream https://github.com/ORIGINAL_OWNER/ayugram-ios.git
```

#### Разработка
```bash
# Создать новую ветку
git checkout -b feature/amazing-feature

# Внести изменения
# ...

# Закоммитить
git add .
git commit -m "Add amazing feature"

# Push в ваш fork
git push origin feature/amazing-feature
```

#### Pull Request
1. Откройте Pull Request на GitHub
2. Опишите изменения
3. Дождитесь review
4. Внесите правки если требуется

## Стандарты кода

### Swift Style Guide
- Следуйте [Swift API Design Guidelines](https://swift.org/documentation/api-design-guidelines/)
- Используйте SwiftLint (если настроен)
- Отступы: 4 пробела
- Максимальная длина строки: 120 символов

### Именование
```swift
// Хорошо ✅
func loadUserData() { }
var isAuthenticated: Bool
let messageCount: Int

// Плохо ❌
func load_user_data() { }
var auth: Bool
let msgCnt: Int
```

### Комментарии
```swift
// MARK: - Section Name
// TODO: Что нужно сделать
// FIXME: Что нужно исправить
// NOTE: Важное примечание
```

### Структура файлов
```swift
// Импорты
import SwiftUI
import Combine

// MARK: - Main Class/Struct
class MyClass {
    // MARK: - Properties
    
    // MARK: - Initialization
    
    // MARK: - Public Methods
    
    // MARK: - Private Methods
}

// MARK: - Extensions
extension MyClass {
    // ...
}

// MARK: - Preview
struct MyView_Previews: PreviewProvider {
    // ...
}
```

## Тестирование

### Unit Tests
```bash
# Запустить тесты
cmd+U в Xcode
# или
xcodebuild test -scheme AyuGram
```

### UI Tests
- Добавляйте UI тесты для новых экранов
- Проверяйте на разных размерах устройств

## Документация

### Коммиты
Используйте [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: добавить режим призрака
fix: исправить падение при отправке сообщения
docs: обновить README
style: исправить форматирование
refactor: переработать TelegramManager
test: добавить тесты для MessageStorage
chore: обновить зависимости
```

### Комментарии к коду
```swift
/// Краткое описание функции
///
/// Более детальное описание что делает функция,
/// когда и как её использовать.
///
/// - Parameters:
///   - chatId: ID чата
///   - text: Текст сообщения
/// - Returns: Отправленное сообщение
/// - Throws: NetworkError если нет соединения
func sendMessage(chatId: Int64, text: String) throws -> Message {
    // ...
}
```

## Процесс review

1. 🔍 Code review от мейнтейнера
2. ✅ Все проверки пройдены
3. 💬 Обсуждение изменений
4. 🔄 Внесение правок
5. ✨ Merge!

## Что нужно проекту

### High Priority
- [ ] Полная интеграция TDLib
- [ ] Unit тесты
- [ ] CI/CD pipeline
- [ ] Документация API

### Medium Priority
- [ ] UI/UX улучшения
- [ ] Локализация на другие языки
- [ ] Accessibility features
- [ ] Dark mode улучшения

### Nice to Have
- [ ] SwiftUI previews для всех экранов
- [ ] Инструменты для дебага
- [ ] Performance оптимизации
- [ ] Анимации

## Вопросы?

- 💬 Telegram: @ayugram_support
- 📧 Email: [your-email]
- 🐛 Issues: GitHub Issues

## Code of Conduct

- Будьте уважительны
- Конструктивная критика
- Помогайте новичкам
- Никакой дискриминации

## Лицензия

Все вклады автоматически подпадают под GPL-3.0 лицензию проекта.

---

Спасибо за вклад в AyuGram! 🙏
