# ИНСТРУКЦИЯ ПО УСТАНОВКЕ И НАСТРОЙКЕ

## Шаг 1: Подготовка окружения

### Требования
- macOS Ventura (13.0) или новее
- Xcode 14.0 или новее
- CocoaPods или Swift Package Manager
- Apple Developer Account (для установки на реальное устройство)

### Установка Xcode
1. Откройте App Store
2. Найдите "Xcode"
3. Нажмите "Установить"
4. Дождитесь завершения установки (может занять 30+ минут)

## Шаг 2: Получение API ключей Telegram

⚠️ **ВАЖНО**: Без этого шага приложение не будет работать!

1. Откройте https://my.telegram.org/apps в браузере
2. Войдите используя свой номер телефона Telegram
3. Нажмите "Create new application"
4. Заполните форму:
   - App title: `AyuGram iOS`
   - Short name: `ayugram`
   - Platform: `iOS`
   - Description: `Modified Telegram client`
5. Нажмите "Create application"
6. **СОХРАНИТЕ** полученные данные:
   - `api_id` (число, например: 12345)
   - `api_hash` (строка, например: "abc123def456...")

## Шаг 3: Настройка проекта

### 3.1 Открыть проект в Xcode
1. Откройте Finder
2. Найдите папку `AyuGram-iOS`
3. Двойной клик на `AyuGram.xcodeproj`

### 3.2 Добавить API ключи
1. В Xcode откройте файл: `AyuGram/Models/TelegramManager.swift`
2. Найдите строки (примерно 29-30):
```swift
let apiId = 0 // Ваш API ID
let apiHash = "" // Ваш API Hash
```
3. Замените на ваши данные:
```swift
let apiId = 12345 // Ваш реальный API ID
let apiHash = "abc123def456..." // Ваш реальный API Hash
```
4. Сохраните файл (Cmd+S)

### 3.3 Изменить Bundle Identifier (если нужно)
1. Выберите проект в навигаторе слева
2. Выберите Target "AyuGram"
3. Вкладка "Signing & Capabilities"
4. Измените "Bundle Identifier" на уникальный (например: `com.yourname.ayugram`)

## Шаг 4: Установка TDLib

TDLib - это библиотека от Telegram для создания клиентов.

### Вариант A: Использование готового binary (проще)

1. Скачайте TDLib.xcframework отсюда:
   https://github.com/Swiftgram/TDLibKit/releases

2. Распакуйте и перетащите в Xcode проект

3. В настройках проекта → General → Frameworks, Libraries добавьте TDLib.xcframework

### Вариант B: Установка через CocoaPods

```bash
# В терминале, в папке проекта
cd AyuGram-iOS

# Установите CocoaPods (если еще не установлен)
sudo gem install cocoapods

# Раскомментируйте строку в Podfile:
# pod 'TDLib', '~> 1.8'

# Установите зависимости
pod install

# ВАЖНО: Теперь открывайте .xcworkspace вместо .xcodeproj!
open AyuGram.xcworkspace
```

### Вариант C: Swift Package Manager

1. В Xcode: File → Add Packages...
2. Вставьте URL: `https://github.com/Swiftgram/TDLibKit.git`
3. Нажмите "Add Package"
4. Выберите нужную версию и подтвердите

### Вариант D: Сборка из исходников (сложно)

```bash
# Клонировать репозиторий TDLib
git clone https://github.com/tdlib/td.git
cd td

# Собрать для iOS
mkdir build-ios
cd build-ios

# Сборка (может занять 30+ минут)
cmake -DCMAKE_BUILD_TYPE=Release \
      -DIOS_PLATFORM=OS \
      -DCMAKE_TOOLCHAIN_FILE=../CMake/iOS.cmake \
      -DTD_ENABLE_JNI=OFF \
      ..

cmake --build . --target prepare_cross_compiling
cd ..

# После сборки добавьте полученный framework в проект
```

## Шаг 5: Настройка подписи кода

### Для симулятора (проще)
1. В Xcode выберите симулятор в списке устройств
2. Нажмите Cmd+R для запуска
3. Готово!

### Для реального устройства
1. Подключите iPhone к компьютеру
2. В Xcode → Signing & Capabilities
3. Team: выберите ваш Apple ID
4. Если нет Apple Developer Account:
   - Нажмите "Add Account"
   - Войдите с Apple ID
   - Выберите Free (ограничения: 7 дней действия, не более 3 приложений)
5. Подключите iPhone
6. На iPhone: Settings → General → VPN & Device Management
7. Доверьте вашему сертификату
8. В Xcode выберите ваш iPhone в списке устройств
9. Нажмите Cmd+R

## Шаг 6: Первый запуск

1. Запустите приложение (Cmd+R)
2. Подождите загрузки
3. Введите номер телефона (с кодом страны, например: +79991234567)
4. Введите код из SMS от Telegram
5. Если включена двухфакторная аутентификация - введите пароль
6. Готово! Приложение готово к использованию

## Возможные проблемы и решения

### Ошибка: "TDLib module not found"
**Решение**: Установите TDLib (см. Шаг 4)

### Ошибка: "Signing for AyuGram requires a development team"
**Решение**: Добавьте Apple ID в Xcode → Preferences → Accounts

### Ошибка: "This app cannot be installed"
**Решение**: На iPhone - Settings → General → Device Management → Доверьте сертификату

### Приложение вылетает при запуске
**Решение**: 
1. Проверьте, что добавили правильные API ID и Hash
2. Проверьте консоль Xcode на наличие ошибок
3. Убедитесь, что TDLib корректно установлен

### "Could not connect to Telegram"
**Решение**:
1. Проверьте интернет-соединение
2. Проверьте API ключи
3. Убедитесь, что Telegram не заблокирован в вашей сети

### Не работает режим призрака
**Примечание**: Это ограничение API Telegram. Полный режим призрака требует модификации протокола, что может привести к блокировке аккаунта.

## Обновление приложения

```bash
cd AyuGram-iOS
git pull origin main

# Если используете CocoaPods
pod update
```

Затем пересоберите проект в Xcode

## Удаление приложения

1. На iPhone: долгое нажатие на иконку → Delete App
2. В Xcode: Product → Clean Build Folder (Shift+Cmd+K)
3. Удалите папку проекта

## Получение помощи

- **GitHub Issues**: https://github.com/yourusername/ayugram-ios/issues
- **Telegram**: @ayugram_support
- **Документация**: См. README.md

## Безопасность

⚠️ **ВАЖНО**:
- Никому не передавайте ваши API ключи
- Используйте приложение на свой страх и риск
- Это неофициальный клиент - возможна блокировка аккаунта
- Рекомендуется тестировать на тестовом аккаунте

## Следующие шаги

После установки изучите:
1. [README.md](README.md) - общая информация
2. Настройки → Функции AyuGram - включение функций
3. Код проекта для кастомизации

Удачи! 🚀
