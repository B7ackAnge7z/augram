# AyuGram для iOS

<div align="center">
  <img src="https://img.shields.io/badge/Platform-iOS%2015.0+-blue.svg" alt="Platform">
  <img src="https://img.shields.io/badge/Swift-5.0-orange.svg" alt="Swift">
  <img src="https://img.shields.io/badge/License-GPL--3.0-green.svg" alt="License">
</div>

Модифицированный клиент Telegram для iOS с расширенными возможностями, вдохновленный AyuGram для Android.

## ✨ Основные функции

### 🎭 Режим призрака
- Скрывает ваш онлайн-статус от других пользователей
- Полный контроль над видимостью

### 🕵️ Режим шпиона
- Читайте сообщения без отметки "прочитано"
- Оставайтесь незамеченным

### 💾 Сохранение истории
- Локальное сохранение всех сообщений
- Восстановление даже после очистки кеша
- Просмотр удаленных и отредактированных сообщений

### 📸 Скриншоты в секретных чатах
- Возможность делать скриншоты в секретных чатах
- Без уведомления собеседника

### 🔎 Дополнительные возможности
- Фильтры сообщений по ключевым словам
- Отображение ID чатов и пользователей
- Анонимная пересылка (без "от кого")
- Настройка внешнего вида
- AyuSync - синхронизация между устройствами

## 🚀 Установка и запуск

### Требования
- macOS 12.0+
- Xcode 14.0+
- iOS 15.0+
- Apple Developer Account (для установки на реальное устройство)

### Шаг 1: Получение API ключей Telegram

1. Перейдите на https://my.telegram.org/apps
2. Войдите с вашим номером телефона
3. Создайте новое приложение
4. Скопируйте `api_id` и `api_hash`

### Шаг 2: Настройка проекта

1. Клонируйте репозиторий:
```bash
git clone https://github.com/yourusername/ayugram-ios.git
cd ayugram-ios
```

2. Откройте `AyuGram.xcodeproj` в Xcode

3. Откройте файл `AyuGram/Models/TelegramManager.swift` и замените:
```swift
let apiId = 0 // Ваш API ID
let apiHash = "" // Ваш API Hash
```

### Шаг 3: Установка TDLib

TDLib (Telegram Database Library) - официальная библиотека Telegram для создания клиентов.

#### Вариант A: Использование CocoaPods

```bash
# Установите CocoaPods если еще не установлен
sudo gem install cocoapods

# Создайте Podfile
pod init

# Добавьте в Podfile:
# pod 'TDLib', '~> 1.8'

# Установите
pod install

# Откройте .xcworkspace вместо .xcodeproj
open AyuGram.xcworkspace
```

#### Вариант B: Ручная установка

1. Скачайте TDLib: https://github.com/tdlib/td
2. Скомпилируйте для iOS
3. Добавьте .framework в проект

### Шаг 4: Запуск

1. Выберите целевое устройство (симулятор или реальное устройство)
2. Нажмите Cmd+R для запуска
3. При первом запуске введите номер телефона и код подтверждения

## 📱 Использование

### Первый запуск
1. Запустите приложение
2. Введите номер телефона в международном формате
3. Введите код из SMS от Telegram
4. Если включена 2FA - введите пароль

### Настройка функций AyuGram
1. Перейдите в **Настройки** → **Функции AyuGram**
2. Включите нужные функции:
   - 👻 **Режим призрака** - скрыть онлайн-статус
   - 🕵️ **Режим шпиона** - читать без "прочитано"
   - 💾 **Сохранять историю** - локальное сохранение
   - 📸 **Скриншоты в секретных чатах**
   - 👁️ **Показывать удаленные сообщения**

### Фильтры сообщений
1. Настройки → Фильтры сообщений
2. Создайте фильтр с ключевыми словами
3. Сообщения с этими словами будут выделены

## ⚠️ Важно

### Безопасность
- Приложение использует те же протоколы шифрования, что и официальный Telegram
- Все данные хранятся локально на устройстве
- Используйте на свой страх и риск

### Ограничения
- Это **неофициальный** клиент Telegram
- Некоторые функции могут нарушать Terms of Service Telegram
- Apple может заблокировать публикацию в App Store
- Рекомендуется для личного использования

### Особенности iOS
- Режим призрака может работать не полностью из-за ограничений API
- Фоновое обновление зависит от настроек iOS
- Требуется джейлбрейк для некоторых расширенных функций

## 🛠️ Разработка

### Архитектура

```
AyuGram-iOS/
├── AyuGram/
│   ├── AyuGramApp.swift          # Точка входа
│   ├── ContentView.swift         # Главный экран
│   ├── Models/                    # Модели данных
│   │   ├── TelegramManager.swift
│   │   ├── AyuGramSettings.swift
│   │   └── Models.swift
│   ├── Views/                     # UI компоненты
│   │   ├── AuthenticationView.swift
│   │   ├── ChatsListView.swift
│   │   ├── ChatView.swift
│   │   └── SettingsView.swift
│   └── Services/                  # Сервисы
│       ├── TDLibManager.swift
│       └── MessageStorage.swift
└── AyuGram.xcodeproj
```

### Технологии
- **SwiftUI** - современный UI фреймворк
- **Combine** - реактивное программирование
- **TDLib** - Telegram API
- **Core Data** - локальное хранилище
- **UserDefaults** - настройки

### Добавление новых функций

1. Создайте новую функцию в `AyuGramSettings.swift`
2. Добавьте UI в соответствующий View
3. Реализуйте логику в `TDLibManager.swift`

## 🤝 Вклад

Проект открыт для вклада! Если хотите добавить функцию:

1. Fork проекта
2. Создайте ветку: `git checkout -b feature/amazing-feature`
3. Commit изменения: `git commit -m 'Add amazing feature'`
4. Push: `git push origin feature/amazing-feature`
5. Создайте Pull Request

## 📄 Лицензия

GPL-3.0 License - см. файл [LICENSE](LICENSE)

## 🙏 Благодарности

- [Telegram](https://telegram.org) - за открытый API
- [TDLib](https://github.com/tdlib/td) - за библиотеку
- [AyuGram Android](https://github.com/AyuGram) - за вдохновение
- [exteraGram](https://github.com/exteraGram) - за идеи

## 📞 Контакты

Вопросы? Проблемы? Предложения?
- Создайте [Issue](https://github.com/yourusername/ayugram-ios/issues)
- Telegram: @ayugram_support

## ⚖️ Disclaimer

Этот проект создан в образовательных целях. Использование модифицированных клиентов может нарушать правила Telegram. Разработчики не несут ответственности за блокировку аккаунтов или другие последствия.

**Используйте на свой страх и риск!**

---

Made with ❤️ for iOS community
