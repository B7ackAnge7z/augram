//
//  ChatsListView.swift
//  AyuGram
//
//  Список чатов
//

import SwiftUI

struct ChatsListView: View {
    @EnvironmentObject var telegramManager: TelegramManager
    @EnvironmentObject var settings: AyuGramSettings
    @State private var searchText = ""
    @State private var showingNewChat = false
    
    var filteredChats: [Chat] {
        if searchText.isEmpty {
            return telegramManager.chats
        }
        return telegramManager.chats.filter { chat in
            chat.title.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    var body: some View {
        NavigationView {
            List {
                ForEach(filteredChats) { chat in
                    NavigationLink(destination: ChatView(chat: chat)) {
                        ChatRowView(chat: chat)
                    }
                }
            }
            .navigationTitle("AyuGram")
            .searchable(text: $searchText, prompt: "Поиск чатов")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingNewChat = true }) {
                        Image(systemName: "square.and.pencil")
                    }
                }
            }
            .sheet(isPresented: $showingNewChat) {
                NewChatView()
            }
            .overlay {
                if telegramManager.chats.isEmpty {
                    VStack(spacing: 20) {
                        Image(systemName: "message.badge")
                            .font(.system(size: 60))
                            .foregroundColor(.secondary)
                        Text("Нет чатов")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        Text("Начните новый диалог")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .refreshable {
                telegramManager.loadChats()
            }
        }
    }
}

struct ChatRowView: View {
    let chat: Chat
    @EnvironmentObject var settings: AyuGramSettings
    
    var body: some View {
        HStack(spacing: 12) {
            // Аватар
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.2))
                    .frame(width: 54, height: 54)
                
                if let photoPath = chat.photoPath {
                    AsyncImage(url: URL(fileURLWithPath: photoPath)) { image in
                        image
                            .resizable()
                            .scaledToFill()
                    } placeholder: {
                        Image(systemName: chatIcon)
                            .foregroundColor(.blue)
                    }
                    .frame(width: 54, height: 54)
                    .clipShape(Circle())
                } else {
                    Image(systemName: chatIcon)
                        .foregroundColor(.blue)
                }
            }
            
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(chat.title)
                        .font(.system(size: settings.fontSize + 1))
                        .fontWeight(.semibold)
                        .lineLimit(1)
                    
                    Spacer()
                    
                    if let lastMessage = chat.lastMessage {
                        Text(lastMessage.date, style: .time)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                HStack {
                    if let lastMessage = chat.lastMessage {
                        HStack(spacing: 4) {
                            if lastMessage.isOutgoing {
                                Image(systemName: lastMessage.isRead ? "checkmark.circle.fill" : "checkmark.circle")
                                    .font(.caption2)
                                    .foregroundColor(lastMessage.isRead ? .blue : .gray)
                            }
                            
                            Text(lastMessage.content.text)
                                .font(.system(size: settings.fontSize - 1))
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                    } else {
                        Text("Нет сообщений")
                            .font(.system(size: settings.fontSize - 1))
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    if chat.unreadCount > 0 {
                        Text("\(chat.unreadCount)")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(chat.isMuted ? Color.gray : settings.accentColor)
                            .clipShape(Capsule())
                    }
                }
                
                // AyuGram: Показывать ID если включено
                if settings.showIDs {
                    Text("ID: \(chat.id)")
                        .font(.caption2)
                        .foregroundColor(.secondary.opacity(0.6))
                }
            }
            
            if chat.isPinned {
                Image(systemName: "pin.fill")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
    
    var chatIcon: String {
        switch chat.type {
        case .privateChat, .secretChat:
            return "person.circle.fill"
        case .group, .supergroup:
            return "person.2.circle.fill"
        case .channel:
            return "megaphone.fill"
        }
    }
}

struct ChatsListView_Previews: PreviewProvider {
    static var previews: some View {
        ChatsListView()
            .environmentObject(TelegramManager())
            .environmentObject(AyuGramSettings())
    }
}
