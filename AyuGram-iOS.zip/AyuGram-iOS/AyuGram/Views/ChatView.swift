//
//  ChatView.swift
//  AyuGram
//
//  Экран чата с сообщениями
//

import SwiftUI

struct ChatView: View {
    let chat: Chat
    @EnvironmentObject var telegramManager: TelegramManager
    @EnvironmentObject var settings: AyuGramSettings
    @State private var messages: [Message] = []
    @State private var messageText = ""
    @State private var showingDeletedMessages = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Сообщения
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(displayedMessages) { message in
                            MessageBubbleView(message: message)
                                .id(message.id)
                        }
                    }
                    .padding()
                }
                .onAppear {
                    if let lastMessage = messages.last {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }
            
            // Поле ввода
            MessageInputView(text: $messageText, onSend: sendMessage)
        }
        .navigationTitle(chat.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Button(action: {}) {
                        Label("Поиск", systemImage: "magnifyingglass")
                    }
                    
                    if settings.showDeletedMessages {
                        Button(action: { showingDeletedMessages.toggle() }) {
                            Label(
                                showingDeletedMessages ? "Скрыть удаленные" : "Показать удаленные",
                                systemImage: "trash"
                            )
                        }
                    }
                    
                    Button(action: {}) {
                        Label("Очистить историю", systemImage: "trash.circle")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .onAppear {
            loadMessages()
        }
    }
    
    var displayedMessages: [Message] {
        if showingDeletedMessages {
            return messages
        }
        return messages.filter { !$0.wasDeleted }
    }
    
    func loadMessages() {
        // TODO: Загрузка сообщений через TDLib
        messages = []
    }
    
    func sendMessage() {
        guard !messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        
        telegramManager.sendMessage(chatId: chat.id, text: messageText)
        messageText = ""
    }
}

struct MessageBubbleView: View {
    let message: Message
    @EnvironmentObject var settings: AyuGramSettings
    
    var body: some View {
        HStack {
            if message.isOutgoing {
                Spacer()
            }
            
            VStack(alignment: message.isOutgoing ? .trailing : .leading, spacing: 4) {
                // Пересланное сообщение
                if let forwardInfo = message.forwardInfo, !settings.disableForwardedFrom {
                    HStack(spacing: 4) {
                        Image(systemName: "arrowshape.turn.up.right")
                            .font(.caption2)
                        Text("Переслано от \(forwardInfo.authorName ?? "пользователя")")
                            .font(.caption)
                    }
                    .foregroundColor(.secondary)
                }
                
                // Ответ на сообщение
                if message.replyToMessageId != nil {
                    HStack {
                        Rectangle()
                            .fill(settings.accentColor)
                            .frame(width: 3)
                        Text("Ответ на сообщение")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(8)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                }
                
                // Содержимое сообщения
                Text(message.content.text)
                    .font(.system(size: settings.fontSize))
                    .padding(10)
                    .background(message.isOutgoing ? settings.accentColor : Color.gray.opacity(0.2))
                    .foregroundColor(message.isOutgoing ? .white : .primary)
                    .cornerRadius(16)
                    .opacity(message.wasDeleted ? 0.5 : 1.0)
                
                HStack(spacing: 4) {
                    // AyuGram: Показывать что сообщение было удалено
                    if message.wasDeleted {
                        Image(systemName: "trash.slash")
                            .font(.caption2)
                            .foregroundColor(.red)
                        Text("Удалено")
                            .font(.caption2)
                            .foregroundColor(.red)
                    }
                    
                    if message.isEdited {
                        Text("изм.")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                    
                    Text(message.date, style: .time)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    if message.isOutgoing {
                        Image(systemName: message.isRead ? "checkmark.circle.fill" : "checkmark.circle")
                            .font(.caption2)
                            .foregroundColor(message.isRead ? settings.accentColor : .gray)
                    }
                }
            }
            
            if !message.isOutgoing {
                Spacer()
            }
        }
    }
}

struct MessageInputView: View {
    @Binding var text: String
    let onSend: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            Button(action: {}) {
                Image(systemName: "plus.circle.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
            }
            
            HStack {
                TextField("Сообщение", text: $text, axis: .vertical)
                    .lineLimit(1...5)
                    .textFieldStyle(.plain)
                
                if !text.isEmpty {
                    Button(action: { text = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding(8)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(20)
            
            Button(action: onSend) {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.title2)
                    .foregroundColor(text.isEmpty ? .gray : .blue)
            }
            .disabled(text.isEmpty)
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(UIColor.systemBackground))
    }
}

struct NewChatView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            List {
                Text("Функция создания нового чата")
            }
            .navigationTitle("Новый чат")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Закрыть") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct ContactsView: View {
    var body: some View {
        NavigationView {
            List {
                Text("Контакты")
            }
            .navigationTitle("Контакты")
        }
    }
}
