//
//  AuthenticationView.swift
//  AyuGram
//
//  Экран авторизации в Telegram
//

import SwiftUI

struct AuthenticationView: View {
    @EnvironmentObject var telegramManager: TelegramManager
    @State private var phoneNumber = ""
    @State private var code = ""
    @State private var password = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer()
                
                // Логотип
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.blue)
                
                Text("AyuGram")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("Модифицированный клиент Telegram")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                // Форма авторизации
                switch telegramManager.connectionState {
                case .connecting:
                    ProgressView("Подключение...")
                    
                case .waitingForPhone:
                    VStack(spacing: 15) {
                        Text("Введите номер телефона")
                            .font(.headline)
                        
                        HStack {
                            Text("+")
                                .foregroundColor(.secondary)
                            TextField("7 XXX XXX XX XX", text: $phoneNumber)
                                .keyboardType(.phonePad)
                                .textContentType(.telephoneNumber)
                        }
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                        
                        Button(action: {
                            telegramManager.sendPhoneNumber(phoneNumber)
                        }) {
                            Text("Продолжить")
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                        .disabled(phoneNumber.isEmpty)
                    }
                    
                case .waitingForCode:
                    VStack(spacing: 15) {
                        Text("Введите код из SMS")
                            .font(.headline)
                        
                        TextField("XXXXX", text: $code)
                            .keyboardType(.numberPad)
                            .textContentType(.oneTimeCode)
                            .multilineTextAlignment(.center)
                            .font(.title)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)
                        
                        Button(action: {
                            telegramManager.sendCode(code)
                        }) {
                            Text("Подтвердить")
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                        .disabled(code.isEmpty)
                    }
                    
                case .waitingForPassword:
                    VStack(spacing: 15) {
                        Text("Введите пароль 2FA")
                            .font(.headline)
                        
                        SecureField("Пароль", text: $password)
                            .textContentType(.password)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)
                        
                        Button(action: {
                            telegramManager.sendPassword(password)
                        }) {
                            Text("Войти")
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                        .disabled(password.isEmpty)
                    }
                    
                case .ready:
                    ProgressView("Загрузка данных...")
                    
                case .closed:
                    Text("Соединение закрыто")
                        .foregroundColor(.red)
                }
                
                Spacer()
                
                Text("Используя AyuGram, вы соглашаетесь с тем, что это неофициальный клиент")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding()
            }
            .padding()
            .navigationBarHidden(true)
        }
    }
}

struct AuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView()
            .environmentObject(TelegramManager())
    }
}
