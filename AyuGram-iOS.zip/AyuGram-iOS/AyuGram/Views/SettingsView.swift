//
//  SettingsView.swift
//  AyuGram
//
//  Настройки приложения с функциями AyuGram
//

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var telegramManager: TelegramManager
    @EnvironmentObject var settings: AyuGramSettings
    
    var body: some View {
        NavigationView {
            List {
                // Профиль
                if let user = telegramManager.user {
                    Section {
                        HStack(spacing: 15) {
                            Circle()
                                .fill(Color.blue.opacity(0.2))
                                .frame(width: 60, height: 60)
                                .overlay {
                                    Text(String(user.firstName.prefix(1)))
                                        .font(.title)
                                        .foregroundColor(.blue)
                                }
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text(user.fullName)
                                    .font(.headline)
                                
                                if let username = user.username {
                                    Text("@\(username)")
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                                
                                if let phone = user.phoneNumber {
                                    Text(phone)
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .padding(.vertical, 8)
                    }
                }
                
                // AyuGram функции
                Section(header: Label("AyuGram", systemImage: "star.fill")) {
                    NavigationLink(destination: AyuGramFeaturesView()) {
                        Label("Функции AyuGram", systemImage: "wand.and.stars")
                    }
                    
                    Toggle(isOn: $settings.ghostMode) {
                        Label("Режим призрака", systemImage: "eye.slash.fill")
                    }
                    
                    Toggle(isOn: $settings.spyMode) {
                        Label("Режим шпиона", systemImage: "binoculars.fill")
                    }
                    
                    Toggle(isOn: $settings.saveMessageHistory) {
                        Label("Сохранять историю", systemImage: "archivebox.fill")
                    }
                }
                .foregroundColor(.purple)
                
                // Внешний вид
                Section(header: Text("Внешний вид")) {
                    Picker("Тема", selection: $settings.theme) {
                        ForEach(AyuGramSettings.Theme.allCases, id: \.self) { theme in
                            Text(theme.rawValue).tag(theme)
                        }
                    }
                    
                    HStack {
                        Text("Размер шрифта")
                        Spacer()
                        Text("\(Int(settings.fontSize))")
                            .foregroundColor(.secondary)
                    }
                    
                    Slider(value: $settings.fontSize, in: 12...20, step: 1)
                }
                
                // Конфиденциальность
                Section(header: Text("Конфиденциальность")) {
                    Toggle(isOn: $settings.allowSecretChatScreenshots) {
                        Label("Скриншоты в секретных чатах", systemImage: "camera.fill")
                    }
                    
                    Toggle(isOn: $settings.showDeletedMessages) {
                        Label("Показывать удаленные", systemImage: "trash.slash")
                    }
                    
                    Toggle(isOn: $settings.disableForwardedFrom) {
                        Label("Скрыть \"переслано от\"", systemImage: "arrowshape.turn.up.right.fill")
                    }
                }
                
                // Дополнительно
                Section(header: Text("Дополнительно")) {
                    Toggle(isOn: $settings.showIDs) {
                        Label("Показывать ID", systemImage: "number")
                    }
                    
                    NavigationLink(destination: MessageFiltersView()) {
                        Label("Фильтры сообщений", systemImage: "line.3.horizontal.decrease.circle")
                    }
                    
                    NavigationLink(destination: AyuSyncView()) {
                        Label("AyuSync", systemImage: "icloud.and.arrow.up")
                    }
                }
                
                // Информация
                Section(header: Text("О приложении")) {
                    HStack {
                        Text("Версия")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }
                    
                    Link(destination: URL(string: "https://github.com/ayugram")!) {
                        Label("GitHub", systemImage: "link")
                    }
                    
                    Button(role: .destructive, action: {
                        telegramManager.logout()
                    }) {
                        Label("Выйти", systemImage: "arrow.right.square")
                    }
                }
            }
            .navigationTitle("Настройки")
        }
    }
}

// MARK: - AyuGram Features
struct AyuGramFeaturesView: View {
    @EnvironmentObject var settings: AyuGramSettings
    
    var body: some View {
        List {
            Section(header: Text("Режимы")) {
                Toggle(isOn: $settings.ghostMode) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Режим призрака")
                            .font(.headline)
                        Text("Скрывает ваш онлайн-статус от других пользователей")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Toggle(isOn: $settings.spyMode) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Режим шпиона")
                            .font(.headline)
                        Text("Читайте сообщения без отметки \"прочитано\"")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            Section(header: Text("Сохранение")) {
                Toggle(isOn: $settings.saveMessageHistory) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Сохранять историю")
                            .font(.headline)
                        Text("Локальное сохранение всех сообщений")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Toggle(isOn: $settings.showDeletedMessages) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Показывать удаленные")
                            .font(.headline)
                        Text("Видеть сообщения, удаленные собеседником")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            Section(header: Text("Секретные чаты")) {
                Toggle(isOn: $settings.allowSecretChatScreenshots) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Скриншоты")
                            .font(.headline)
                        Text("Разрешить скриншоты в секретных чатах")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            Section(header: Text("Другое")) {
                Toggle(isOn: $settings.disableForwardedFrom) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Анонимная пересылка")
                            .font(.headline)
                        Text("Отключить пересылку \"от кого\"")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Toggle(isOn: $settings.showIDs) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Показывать ID")
                            .font(.headline)
                        Text("ID чатов и пользователей в интерфейсе")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .navigationTitle("Функции AyuGram")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Message Filters
struct MessageFiltersView: View {
    @EnvironmentObject var settings: AyuGramSettings
    @State private var showingAddFilter = false
    
    var body: some View {
        List {
            Section(header: Text("Активные фильтры")) {
                if settings.messageFilters.isEmpty {
                    Text("Нет фильтров")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(settings.messageFilters) { filter in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(filter.name)
                                .font(.headline)
                            Text(filter.keywords.joined(separator: ", "))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .onDelete(perform: deleteFilter)
                }
            }
            
            Section {
                Button(action: { showingAddFilter = true }) {
                    Label("Добавить фильтр", systemImage: "plus.circle.fill")
                }
            }
        }
        .navigationTitle("Фильтры сообщений")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingAddFilter) {
            AddFilterView()
        }
    }
    
    func deleteFilter(at offsets: IndexSet) {
        settings.messageFilters.remove(atOffsets: offsets)
    }
}

struct AddFilterView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var settings: AyuGramSettings
    @State private var filterName = ""
    @State private var keywords = ""
    
    var body: some View {
        NavigationView {
            Form {
                TextField("Название фильтра", text: $filterName)
                TextField("Ключевые слова (через запятую)", text: $keywords)
                
                Section {
                    Button("Создать") {
                        let keywordArray = keywords.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                        let filter = MessageFilter(name: filterName, keywords: keywordArray)
                        settings.messageFilters.append(filter)
                        dismiss()
                    }
                    .disabled(filterName.isEmpty || keywords.isEmpty)
                }
            }
            .navigationTitle("Новый фильтр")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Отмена") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - AyuSync
struct AyuSyncView: View {
    @EnvironmentObject var settings: AyuGramSettings
    
    var body: some View {
        Form {
            Section(header: Text("AyuSync")) {
                Toggle("Включить синхронизацию", isOn: $settings.ayuSyncEnabled)
                
                if settings.ayuSyncEnabled {
                    TextField("Токен", text: $settings.ayuSyncToken)
                        .textContentType(.password)
                    
                    Text("AyuSync синхронизирует настройки между устройствами")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .navigationTitle("AyuSync")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .environmentObject(TelegramManager())
            .environmentObject(AyuGramSettings())
    }
}
