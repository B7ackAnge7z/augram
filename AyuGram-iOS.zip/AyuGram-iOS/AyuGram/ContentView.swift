//
//  ContentView.swift
//  AyuGram
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var telegramManager: TelegramManager
    @EnvironmentObject var settings: AyuGramSettings
    @State private var selectedTab = 0
    
    var body: some View {
        if !telegramManager.isAuthenticated {
            AuthenticationView()
        } else {
            TabView(selection: $selectedTab) {
                ChatsListView()
                    .tabItem {
                        Label("Чаты", systemImage: "message.fill")
                    }
                    .tag(0)
                
                ContactsView()
                    .tabItem {
                        Label("Контакты", systemImage: "person.2.fill")
                    }
                    .tag(1)
                
                SettingsView()
                    .tabItem {
                        Label("Настройки", systemImage: "gearshape.fill")
                    }
                    .tag(2)
            }
            .accentColor(settings.accentColor)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(TelegramManager())
            .environmentObject(AyuGramSettings())
    }
}
