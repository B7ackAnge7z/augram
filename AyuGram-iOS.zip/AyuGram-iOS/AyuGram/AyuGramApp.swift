//
//  AyuGramApp.swift
//  AyuGram для iOS
//
//  Модифицированный клиент Telegram с расширенными возможностями
//

import SwiftUI

@main
struct AyuGramApp: App {
    @StateObject private var telegramManager = TelegramManager()
    @StateObject private var settingsManager = AyuGramSettings()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(telegramManager)
                .environmentObject(settingsManager)
                .preferredColorScheme(settingsManager.theme == .dark ? .dark : .light)
        }
    }
}
