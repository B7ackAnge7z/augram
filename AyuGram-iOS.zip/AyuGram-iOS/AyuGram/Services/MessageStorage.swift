//
//  MessageStorage.swift
//  AyuGram
//
//  Локальное хранилище сообщений (для функции сохранения истории)
//

import Foundation
import CoreData

class MessageStorage {
    static let shared = MessageStorage()
    
    private init() {
        setupCoreData()
    }
    
    // MARK: - Core Data
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "AyuGramData")
        container.loadPersistentStores { description, error in
            if let error = error {
                print("❌ Core Data error: \(error)")
            }
        }
        return container
    }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    private func setupCoreData() {
        // TODO: Создать Core Data модель для хранения сообщений
    }
    
    // MARK: - Save Message
    
    func saveMessage(_ message: Message, reason: StoredMessage.StorageReason) {
        let storedMessage = StoredMessage(
            originalMessage: message,
            savedAt: Date(),
            reason: reason
        )
        
        // Сохранение в Core Data или UserDefaults
        saveToStorage(storedMessage)
        
        print("💾 Сообщение сохранено: \(message.content.text) (причина: \(reason.rawValue))")
    }
    
    private func saveToStorage(_ message: StoredMessage) {
        // TODO: Реальное сохранение в Core Data
        
        // Временное решение - сохранение в UserDefaults (не рекомендуется для большого объема)
        var storedMessages = getStoredMessages()
        storedMessages.append(message)
        
        if let encoded = try? JSONEncoder().encode(storedMessages) {
            UserDefaults.standard.set(encoded, forKey: "storedMessages")
        }
    }
    
    // MARK: - Get Messages
    
    func getStoredMessages() -> [StoredMessage] {
        guard let data = UserDefaults.standard.data(forKey: "storedMessages"),
              let messages = try? JSONDecoder().decode([StoredMessage].self, from: data) else {
            return []
        }
        return messages
    }
    
    func getDeletedMessages(chatId: Int64) -> [StoredMessage] {
        return getStoredMessages().filter {
            $0.originalMessage.chatId == chatId && $0.reason == .deleted
        }
    }
    
    func getEditedMessages(chatId: Int64) -> [StoredMessage] {
        return getStoredMessages().filter {
            $0.originalMessage.chatId == chatId && $0.reason == .edited
        }
    }
    
    // MARK: - Delete
    
    func clearHistory(chatId: Int64? = nil) {
        if let chatId = chatId {
            var messages = getStoredMessages()
            messages.removeAll { $0.originalMessage.chatId == chatId }
            
            if let encoded = try? JSONEncoder().encode(messages) {
                UserDefaults.standard.set(encoded, forKey: "storedMessages")
            }
        } else {
            UserDefaults.standard.removeObject(forKey: "storedMessages")
        }
        
        print("🗑️ История очищена")
    }
}
