//
//  TelegramManager.swift
//  AyuGram
//
//  Основной менеджер для работы с Telegram API через TDLib
//

import Foundation
import Combine

class TelegramManager: ObservableObject {
    @Published var isAuthenticated = false
    @Published var chats: [Chat] = []
    @Published var user: User?
    @Published var connectionState: ConnectionState = .connecting
    
    private var tdlib: TDLibManager?
    
    enum ConnectionState {
        case connecting
        case waitingForPhone
        case waitingForCode
        case waitingForPassword
        case ready
        case closed
    }
    
    init() {
        setupTDLib()
    }
    
    private func setupTDLib() {
        // Инициализация TDLib
        tdlib = TDLibManager()
        tdlib?.delegate = self
        
        // Тестовые API credentials от Telegram
        // Для продакшена получите свои на https://my.telegram.org/apps
        let apiId = 94575 // Тестовый API ID
        let apiHash = "a3406de8d171bb422bb6ddf3bbd800e2" // Тестовый API Hash
        
        tdlib?.initialize(apiId: apiId, apiHash: apiHash)
    }
    
    func sendPhoneNumber(_ phone: String) {
        tdlib?.sendPhoneNumber(phone)
    }
    
    func sendCode(_ code: String) {
        tdlib?.sendCode(code)
    }
    
    func sendPassword(_ password: String) {
        tdlib?.sendPassword(password)
    }
    
    func loadChats() {
        tdlib?.loadChats()
    }
    
    func sendMessage(chatId: Int64, text: String) {
        tdlib?.sendMessage(chatId: chatId, text: text)
    }
    
    func logout() {
        tdlib?.logout()
        isAuthenticated = false
        chats = []
        user = nil
    }
}

// MARK: - TDLib Delegate
extension TelegramManager: TDLibDelegate {
    func onAuthorizationStateUpdated(_ state: TelegramManager.ConnectionState) {
        DispatchQueue.main.async {
            self.connectionState = state
            if state == .ready {
                self.isAuthenticated = true
                self.loadChats()
            }
        }
    }
    
    func onChatsLoaded(_ chats: [Chat]) {
        DispatchQueue.main.async {
            self.chats = chats
        }
    }
    
    func onUserUpdated(_ user: User) {
        DispatchQueue.main.async {
            self.user = user
        }
    }
}

// MARK: - TDLib Protocol
protocol TDLibDelegate: AnyObject {
    func onAuthorizationStateUpdated(_ state: TelegramManager.ConnectionState)
    func onChatsLoaded(_ chats: [Chat])
    func onUserUpdated(_ user: User)
}
