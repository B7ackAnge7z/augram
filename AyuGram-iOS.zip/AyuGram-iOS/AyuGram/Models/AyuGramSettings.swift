//
//  AyuGramSettings.swift
//  AyuGram
//
//  Настройки AyuGram - уникальные функции
//

import SwiftUI
import Combine

class AyuGramSettings: ObservableObject {
    
    // MARK: - Основные настройки AyuGram
    
    /// Режим призрака - скрывает онлайн-статус
    @Published var ghostMode: Bool {
        didSet { UserDefaults.standard.set(ghostMode, forKey: "ghostMode") }
    }
    
    /// Сохранять историю сообщений локально
    @Published var saveMessageHistory: Bool {
        didSet { UserDefaults.standard.set(saveMessageHistory, forKey: "saveMessageHistory") }
    }
    
    /// Разрешить скриншоты в секретных чатах
    @Published var allowSecretChatScreenshots: Bool {
        didSet { UserDefaults.standard.set(allowSecretChatScreenshots, forKey: "allowSecretChatScreenshots") }
    }
    
    /// Показывать удаленные сообщения
    @Published var showDeletedMessages: Bool {
        didSet { UserDefaults.standard.set(showDeletedMessages, forKey: "showDeletedMessages") }
    }
    
    /// Режим шпиона - читать без отметки "прочитано"
    @Published var spyMode: Bool {
        didSet { UserDefaults.standard.set(spyMode, forKey: "spyMode") }
    }
    
    /// Отключить пересылку "отсюда"
    @Published var disableForwardedFrom: Bool {
        didSet { UserDefaults.standard.set(disableForwardedFrom, forKey: "disableForwardedFrom") }
    }
    
    /// Показывать ID чатов и пользователей
    @Published var showIDs: Bool {
        didSet { UserDefaults.standard.set(showIDs, forKey: "showIDs") }
    }
    
    // MARK: - Настройки внешнего вида
    
    @Published var theme: Theme {
        didSet { 
            UserDefaults.standard.set(theme.rawValue, forKey: "theme") 
        }
    }
    
    @Published var accentColor: Color {
        didSet {
            if let data = try? JSONEncoder().encode(accentColor.description) {
                UserDefaults.standard.set(data, forKey: "accentColor")
            }
        }
    }
    
    @Published var fontSize: CGFloat {
        didSet { UserDefaults.standard.set(fontSize, forKey: "fontSize") }
    }
    
    // MARK: - Фильтры сообщений
    
    @Published var messageFilters: [MessageFilter] {
        didSet {
            if let data = try? JSONEncoder().encode(messageFilters) {
                UserDefaults.standard.set(data, forKey: "messageFilters")
            }
        }
    }
    
    // MARK: - AyuSync
    
    @Published var ayuSyncEnabled: Bool {
        didSet { UserDefaults.standard.set(ayuSyncEnabled, forKey: "ayuSyncEnabled") }
    }
    
    @Published var ayuSyncToken: String {
        didSet { UserDefaults.standard.set(ayuSyncToken, forKey: "ayuSyncToken") }
    }
    
    // MARK: - Initialization
    
    init() {
        self.ghostMode = UserDefaults.standard.bool(forKey: "ghostMode")
        self.saveMessageHistory = UserDefaults.standard.bool(forKey: "saveMessageHistory")
        self.allowSecretChatScreenshots = UserDefaults.standard.bool(forKey: "allowSecretChatScreenshots")
        self.showDeletedMessages = UserDefaults.standard.bool(forKey: "showDeletedMessages")
        self.spyMode = UserDefaults.standard.bool(forKey: "spyMode")
        self.disableForwardedFrom = UserDefaults.standard.bool(forKey: "disableForwardedFrom")
        self.showIDs = UserDefaults.standard.bool(forKey: "showIDs")
        
        let themeRaw = UserDefaults.standard.string(forKey: "theme") ?? Theme.system.rawValue
        self.theme = Theme(rawValue: themeRaw) ?? .system
        
        self.accentColor = .blue // Default
        self.fontSize = UserDefaults.standard.object(forKey: "fontSize") as? CGFloat ?? 16
        
        self.messageFilters = []
        if let data = UserDefaults.standard.data(forKey: "messageFilters"),
           let filters = try? JSONDecoder().decode([MessageFilter].self, from: data) {
            self.messageFilters = filters
        }
        
        self.ayuSyncEnabled = UserDefaults.standard.bool(forKey: "ayuSyncEnabled")
        self.ayuSyncToken = UserDefaults.standard.string(forKey: "ayuSyncToken") ?? ""
    }
    
    enum Theme: String, CaseIterable {
        case light = "Светлая"
        case dark = "Темная"
        case system = "Системная"
    }
}

// MARK: - Message Filter
struct MessageFilter: Codable, Identifiable {
    let id: UUID
    var name: String
    var keywords: [String]
    var enabled: Bool
    
    init(name: String, keywords: [String], enabled: Bool = true) {
        self.id = UUID()
        self.name = name
        self.keywords = keywords
        self.enabled = enabled
    }
}
