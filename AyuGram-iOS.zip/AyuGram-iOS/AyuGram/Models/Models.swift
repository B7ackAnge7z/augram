//
//  Models.swift
//  AyuGram
//
//  Модели данных для работы с Telegram
//

import Foundation

// MARK: - User
struct User: Identifiable, Codable {
    let id: Int64
    var firstName: String
    var lastName: String?
    var username: String?
    var phoneNumber: String?
    var photoPath: String?
    var isOnline: Bool
    var lastSeen: Date?
    
    var fullName: String {
        if let lastName = lastName {
            return "\(firstName) \(lastName)"
        }
        return firstName
    }
    
    var displayName: String {
        if let username = username {
            return "@\(username)"
        }
        return fullName
    }
}

// MARK: - Chat
struct Chat: Identifiable, Codable {
    let id: Int64
    var title: String
    var type: ChatType
    var photoPath: String?
    var lastMessage: Message?
    var unreadCount: Int
    var isPinned: Bool
    var isMuted: Bool
    var draftMessage: String?
    
    enum ChatType: String, Codable {
        case privateChat = "private"
        case group = "group"
        case supergroup = "supergroup"
        case channel = "channel"
        case secretChat = "secret"
    }
}

// MARK: - Message
struct Message: Identifiable, Codable {
    let id: Int64
    let chatId: Int64
    let senderId: Int64
    var content: MessageContent
    var date: Date
    var isOutgoing: Bool
    var isRead: Bool
    var isEdited: Bool
    var replyToMessageId: Int64?
    var forwardInfo: ForwardInfo?
    
    // AyuGram специфичные поля
    var wasDeleted: Bool = false
    var deletedAt: Date?
    var originalContent: MessageContent?
}

// MARK: - Message Content
enum MessageContent: Codable {
    case text(String)
    case photo(path: String, caption: String?)
    case video(path: String, caption: String?)
    case voice(path: String, duration: Int)
    case document(path: String, fileName: String)
    case sticker(emojiPath: String)
    case animation(path: String)
    case location(latitude: Double, longitude: Double)
    case contact(phoneNumber: String, firstName: String, lastName: String?)
    case poll(question: String, options: [String])
    case unsupported
    
    var text: String {
        switch self {
        case .text(let content):
            return content
        case .photo(_, let caption):
            return caption ?? "Фото"
        case .video(_, let caption):
            return caption ?? "Видео"
        case .voice:
            return "Голосовое сообщение"
        case .document(_, let fileName):
            return fileName
        case .sticker:
            return "Стикер"
        case .animation:
            return "GIF"
        case .location:
            return "Местоположение"
        case .contact(_, let firstName, let lastName):
            return "Контакт: \(firstName) \(lastName ?? "")"
        case .poll(let question, _):
            return "Опрос: \(question)"
        case .unsupported:
            return "Неподдерживаемое сообщение"
        }
    }
}

// MARK: - Forward Info
struct ForwardInfo: Codable {
    var fromChatId: Int64?
    var fromUserId: Int64?
    var date: Date
    var authorName: String?
}

// MARK: - Stored Message (for history)
struct StoredMessage: Codable {
    let originalMessage: Message
    let savedAt: Date
    var reason: StorageReason
    
    enum StorageReason: String, Codable {
        case deleted = "deleted"
        case edited = "edited"
        case backup = "backup"
    }
}
